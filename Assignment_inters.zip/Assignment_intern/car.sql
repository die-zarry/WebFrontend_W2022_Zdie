 UPDATE department 
 set EmployeeNumber = "56333445"
 WHERE ID = 102;

"Write a query to count the number of employees under DepartmentNumber 10."

 SELECT COUNT(EmployeeNumber)
FROM Department
WHERE ID = 10;

"Write a query to sort Department table in decedent order by EmployeeNumber."

 SELECT EmployeeNumber
FROM Department
ORDER BY EmployeeNumber DESC;

"A type of join that includes rows that returns matching values in both tables."

INNER JOIN
"Select all the columns from a table “Finance”?
" 
d. SELECT * FROM Finance;
" Select all records from a table named “Premium” where the value of the column
“CompanyName” is “UNQ”?
"
d. SELECT * FROM Premium WHERE CompanyName=’UNQ’;
"Select all records from the “Company” table where the name of the column,
“VendorName” starts with a “T”.
 "
e. SELECT * FROM Company WHERE VendorName LIKE ’T%’;

"the relation between INVOICE and LINE is One or many. Which means an invoice can have one or many lines.
*/Object Oriented Programming is is a style of programming in which every thing can be interprested as an 
object.Therefore everything has a property or attribute(things that caracterise the object) and method
(action the object can perform.)attached them.*/

I am not too much familiar with REST API. 

My expectation is too be able to embelish my portfolio, build a network of people or build my social capital. 
